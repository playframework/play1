Play LESS module
================

This module allows you to use LESS (http://www.lesscss.org) directly in your Play! project. The documentation is in /documentation.
