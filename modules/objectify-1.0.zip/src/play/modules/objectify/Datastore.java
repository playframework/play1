package play.modules.objectify;

/**
 * A friendly named convenient subclass of {@link play.modules.objectify.ObjectifyService}.
 * 
 * @author David Cheong
 * @since 23/04/2010
 */
public class Datastore extends ObjectifyService {
}
