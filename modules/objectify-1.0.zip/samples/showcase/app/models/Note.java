package models;

/**
 * @author David Cheong
 * @since 28/04/2010
 */
public class Note {

    public String text;
    public boolean internal;

}
