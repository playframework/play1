package play.modules.playerrors;

import play.PlayPlugin;

public class ErrorPlugin extends PlayPlugin {
	
	@Override
	public void onInvocationException(java.lang.Throwable e) {
		PlayErrors.reportError(e);
	}
	
}
