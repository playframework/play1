package play.modules.jelastic.model;

public class DebugResponse {
}
