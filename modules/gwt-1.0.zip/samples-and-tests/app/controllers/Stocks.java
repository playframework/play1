package controllers;

/**
 * CRUD for Stocks.
 * Visit /admin/stocks
 */
public class Stocks extends CRUD {
    
}

