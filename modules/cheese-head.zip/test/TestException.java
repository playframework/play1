import java.util.List;

import org.junit.Test;

import play.modules.cheese.Customer;
import play.modules.cheese.Service;
import play.modules.cheese.Subscription;
import play.test.UnitTest;


public class TestException extends UnitTest {
	@Test 
	public void testService() {
        Service sub = new Service("lmcalpin@gmail.com", "cheez!t", "AWESOME_SERVICE");
		System.out.println(sub.getPricingPlans());
	}
}
