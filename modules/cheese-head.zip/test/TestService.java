import java.math.BigDecimal;
import java.util.List;

import org.junit.Test;

import play.modules.cheese.Customer;
import play.modules.cheese.Item;
import play.modules.cheese.Plan;
import play.modules.cheese.Service;
import play.modules.cheese.Subscription;
import play.test.UnitTest;


public class TestService extends UnitTest {
	@Test 
	public void testService() {
		Service sub = new Service("lmcalpin@gmail.com", "cheez!t", "AWESOME_SERVICE");
		//sub.deleteCustomer("1496335378");
		//sub.addCustomer("Test1", "Test", "User", "testuser@testuser.com", "FREE");
		List<Customer> customers = sub.getCustomers();
//        //Customer customer = sub.getCustomer(String.valueOf(1496335378L));
		for (Customer customer : customers) {
	        printCustomer(customer);
		}
//        List<Plan> plans = sub.getPricingPlans();
//        for (Plan plan : plans) {
//            System.out.println(plan.getCode());
//        }
//        Plan plan = sub.getPricingPlan("FREE");

        //Customer customer = sub.getCustomer("Test1");
        //customer.setItemUsage("Foo", new BigDecimal("1"));
	}

    private void printCustomer(Customer customer) {
        System.out.println(customer);
		System.out.println(customer.getFirstName());
		List<Subscription> subs = customer.getSubscriptions();
		for (Subscription s : subs) {
			System.out.println(s.getId() + " canceled? " + s.isCanceled());
			for (Plan p : s.getPlans()) {
				System.out.println(" - " + p.getCode());
				for (Item i : p.getItems()) {
				    System.out.println(" --- " + i.getCode() + " , " + i.getName());
				}
			}
		}
    }
}
