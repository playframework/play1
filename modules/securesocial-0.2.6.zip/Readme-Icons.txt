The icons used in this module (except the MyOpenID icon) are part of the WPZOOM Social Networking Icon Set by WPZOOM designed by David Ferreira.

They are licensed under a Creative Commons Attribution-Share Alike 3.0 Unported License (http://creativecommons.org/licenses/by-nc-sa/3.0/).

Please read more at: 
http://www.iconfinder.com/browse/iconset/WPZOOM_Social_Networking_Icon_Set/#readme


