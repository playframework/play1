play clean
play deps --sync
play ec
