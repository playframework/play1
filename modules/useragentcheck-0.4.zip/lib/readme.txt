just a placeholder to keep the lib folder in git
