(function($) {
    $(document).ready(function() {

        $("#flash-container").delay(5000).hide(2000);

    });
})(jQuery);