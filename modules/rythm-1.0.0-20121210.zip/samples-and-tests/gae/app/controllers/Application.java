package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

import com.greenlaw110.rythm.*;
import com.greenlaw110.rythm.play.*;

public class Application extends Controller {

    public static void index() {
        render();
    }
	
}