package play.modules.jqvalidate.singleton;

import java.util.Map;

import play.Play;
import play.Play.Mode;

public abstract class MapSingleton {
	private static Map<String, Map<String, String>> classFieldValidation;

	public static void setClassFieldValidation(
			Map<String, Map<String, String>> classFieldValidation) {
		if (MapSingleton.classFieldValidation == null || Play.mode == Mode.DEV) {
			MapSingleton.classFieldValidation = classFieldValidation;
		}
		// System.out.println("HashMapSingleton.setClassFieldValidation()");
	}

	public static Map<String, Map<String, String>> getClassFieldValidation() {
		// System.out.println("HashMapSingleton.getClassFieldValidation()");
		return classFieldValidation;

	}

}
