package models;

import java.util.Date;

public class Driver {
	
	public String name;
	public Date dob;

	public Driver(){
		
	}

	public Driver(String name, Date dob) {
		this.name = name;
		this.dob = dob;
	}
	
	

}
