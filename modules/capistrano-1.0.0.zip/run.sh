#!/bin/bash

${PLAY_PATH}/play ${PLAY_CMD} $* &

