package play.modules.jpagen;

public class Column {
	
	public String columnName;
	public String columnType;
	public String columnPropertyName;
	public Integer max;
	public boolean nullable = true;
	public boolean primary = false;

}
