Play Antify Module
==================

Generates Ant project file for your Play application that can be used for example with continuous integration server
like Hudson.




