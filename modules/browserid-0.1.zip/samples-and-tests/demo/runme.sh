#!/bin/sh

# figure the application path
PRG="$0"
# need this for relative symlinks
while [ -h "$PRG" ] ; do
   PRG=`readlink "$PRG"`
done
scriptdir=`dirname "$PRG"`

echo Starting application in $scriptdir

play deps $scriptdir --sync
play run $scriptdir

