package controllers;

import play.mvc.Controller;
import play.mvc.With;
import controllers.BrowserIDSecure;

@With(BrowserIDSecure.class)
public class Application extends Controller {

    public static void index() {
        render();
    }
	
}