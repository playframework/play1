package controllers;

import models.OtherIdStringModelNativeEmbedded;

 
@CRUD.For(OtherIdStringModelNativeEmbedded.class)
public class OtherIdStringModelsNativeEmbedded extends controllers.CRUD {    

}
