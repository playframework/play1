package controllers;

import models.OtherIdStringModel3;
 
@CRUD.For(OtherIdStringModel3.class)
public class OtherIdStringModels3 extends controllers.CRUD {    

}
