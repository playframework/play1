package controllers;

import models.BlobModel;
 
@CRUD.For(BlobModel.class)
public class BlobModels extends controllers.CRUD {    

}
