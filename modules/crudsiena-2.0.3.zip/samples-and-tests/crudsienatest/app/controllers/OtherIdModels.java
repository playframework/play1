package controllers;

import models.OtherIdModel;
 
@CRUD.For(OtherIdModel.class)
public class OtherIdModels extends controllers.CRUD {    

}
