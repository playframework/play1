package controllers;

import models.Employee;
import models.Fourword;
import models.FourwordUser;
 
@CRUD.For(FourwordUser.class)
public class FourwordUsers extends controllers.CRUD {    

}
