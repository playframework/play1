package controllers;

import models.Employee;
 
@CRUD.For(Employee.class)
public class Employees extends controllers.CRUD {    

}
