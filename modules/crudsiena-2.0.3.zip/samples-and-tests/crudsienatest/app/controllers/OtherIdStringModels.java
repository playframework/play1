package controllers;

import models.OtherIdModel;
import models.OtherIdStringModel;
 
@CRUD.For(OtherIdStringModel.class)
public class OtherIdStringModels extends controllers.CRUD {    

}
