package play.modules.vhost;

public interface VirtualHostListener
{

  public void virtualHostUnloaded(VirtualHost ch);

}
