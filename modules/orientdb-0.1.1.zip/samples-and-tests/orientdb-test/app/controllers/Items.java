package controllers;

import models.Company;

public class Items extends CRUD {

}
