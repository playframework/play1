package controllers;

import models.Company;

@CRUD.For(Company.class)
public class Companies extends CRUD {

}
