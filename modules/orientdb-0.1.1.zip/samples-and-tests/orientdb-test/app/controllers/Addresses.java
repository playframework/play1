package controllers;

import models.Address;

@CRUD.For(Address.class)
public class Addresses extends CRUD {

}
