package controllers;

import models.Country;

@CRUD.For(Country.class)
public class Countries extends CRUD {

}
