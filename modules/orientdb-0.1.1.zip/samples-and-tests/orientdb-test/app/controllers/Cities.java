package controllers;

import models.City;

@CRUD.For(City.class)
public class Cities extends CRUD {

}
