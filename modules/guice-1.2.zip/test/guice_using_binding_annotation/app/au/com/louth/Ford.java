package au.com.louth;

public class Ford implements Car {

	@Override
	public String drive() {
		return "Driving a Ford";
	}

}
