# Force.com module for Play! Framework

# Usage

See the [module manual](https://github.com/jesperfj/play-force/blob/master/documentation/manual/home.textile) for usage
