package play.modules.reverseproxy.annotations;

public enum SchemeType {
    UNSPECIFIED,
    HTTP,
    HTTPS
}
