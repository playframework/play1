package controllers.jqueryui;

import play.mvc.Controller;

/**
 *
 */
public class Demo extends Controller {

	public static void index() {
		render();
	}

}
