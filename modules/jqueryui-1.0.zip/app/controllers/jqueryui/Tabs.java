package controllers.jqueryui;

/**
 * Tabs example support.
 */
public class Tabs extends JQueryUI {

}
