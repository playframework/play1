package controllers.jqueryui;

import play.mvc.Controller;

public class JQueryUI extends Controller {

	public static void index() {
		render();
	}
}
