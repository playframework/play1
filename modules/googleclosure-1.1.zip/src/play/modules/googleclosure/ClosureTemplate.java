package play.modules.googleclosure;

import play.vfs.VirtualFile;

public class ClosureTemplate {
	public String name;
	public VirtualFile templateFile;
	public VirtualFile jsFile;    
	public Long timestamp = System.currentTimeMillis();
	
	public ClosureTemplate(String name, VirtualFile templateFile){
		this.name = name;
		this.templateFile = templateFile;
	}			
}

