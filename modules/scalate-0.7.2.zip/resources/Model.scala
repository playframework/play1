package models

import play._
import play.mvc._

case class DummyModel(s:String)
